import 'package:flutter/material.dart';
import '../app/theme/app_colors.dart';

class StatusChipRow extends StatelessWidget {
  final int present;
  final int late;
  final int absent;
  const StatusChipRow({
    super.key,
    required this.present,
    required this.late,
    required this.absent,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _chip('$present', 'Present', AppColors.present, AppColors.presentBg),
        const SizedBox(width: 8),
        _chip('$late', 'Late', AppColors.late, AppColors.lateBg),
        const SizedBox(width: 8),
        _chip('$absent', 'Absent', AppColors.absent, AppColors.absentBg),
      ],
    );
  }

  Widget _chip(String number, String label, Color color, Color bg) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Text(
              number,
              style: TextStyle(
                fontFamily: 'Sora',
                fontWeight: FontWeight.w800,
                fontSize: 24,
                height: 1.1,
                color: color,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
